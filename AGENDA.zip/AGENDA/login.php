<?php // login.php
$hn = 'localhost';
$db = 'agenda';
$un = 'root';
$pw = '';
?>